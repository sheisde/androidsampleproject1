package com.example.myapplication;

public class prevalent {
    public  static User currentonlineuser;
    public  static final String UserEmailKey = "UserEmail";
    public  static final String UserPasswordKey = "UserPassword";

}
