package com.example.myapplication;

public class User {
    public String email;
    public String Role;
    public  String   Subject;

    public User(){}

    public User ( String Email, String Role, String Subject){

        this.email = Email;

        this.Role = Role;
        this.Subject = Subject;
    }}
